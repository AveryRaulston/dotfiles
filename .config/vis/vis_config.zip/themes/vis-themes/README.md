# vis-themes
My themes for the vis editor

Here you can find some themes I created for the [vis editor](https://github.com/martanne/vis).

I'm using st as terminal, hence themes were tested there. Anyway, I didn't accurately check if they can work with 16 or 256 colors or whatelse.

Try yourself and fork and modify.

All the themes are released under permissive licenses.
